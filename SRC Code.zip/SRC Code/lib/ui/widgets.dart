import 'package:flutter/material.dart';
import '../theme.dart';

class CircularIconButton extends StatelessWidget {
  final Widget icon;
  final VoidCallback? onPressed;
  final EdgeInsetsGeometry? margin;

  const CircularIconButton({
    super.key,
    required this.icon,
    this.onPressed,
    this.margin,
  });

  @override
  Widget build(BuildContext context) {
    final isDark = Theme.of(context).brightness == Brightness.dark;
    return Container(
      margin: margin ?? const EdgeInsets.all(8),
      decoration: BoxDecoration(
        color: isDark ? AppColors.cardDark : const Color(0xFFF4F5F7),
        shape: BoxShape.circle,
      ),
      child: IconButton(
        icon: icon,
        onPressed: onPressed,
        iconSize: 20,
        constraints: const BoxConstraints(minWidth: 40, minHeight: 40),
        padding: EdgeInsets.zero,
      ),
    );
  }
}

class CircularBackButton extends StatelessWidget {
  const CircularBackButton({super.key});

  @override
  Widget build(BuildContext context) {
    return CircularIconButton(
      icon: const Icon(Icons.arrow_back),
      onPressed: () => Navigator.maybePop(context),
    );
  }
}

class PrimaryButton extends StatelessWidget {
  final String label;
  final VoidCallback? onPressed;
  const PrimaryButton({super.key, required this.label, this.onPressed});
  @override
  Widget build(BuildContext context) {
    return SafeArea(
      child: Padding(
        padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 12),
        child: SizedBox(
          width: double.infinity,
          child: ElevatedButton(
            style: ElevatedButton.styleFrom(
              backgroundColor: AppColors.purple,
              foregroundColor: Colors.white,
              padding: const EdgeInsets.symmetric(vertical: 18),
              shape: RoundedRectangleBorder(
                borderRadius: BorderRadius.circular(16),
              ),
              elevation: 0,
            ),
            onPressed: onPressed,
            child: Text(label, style: const TextStyle(fontSize: 18, fontWeight: FontWeight.w600)),
          ),
        ),
      ),
    );
  }
}

class PillButton extends StatelessWidget {
  final String label;
  final bool primary;
  final VoidCallback? onPressed;
  const PillButton({super.key, required this.label, this.primary = false, this.onPressed});
  @override
  Widget build(BuildContext context) {
    final isDark = Theme.of(context).brightness == Brightness.dark;
    final bg = primary ? AppColors.purple : (isDark ? AppColors.cardDark : const Color(0xFFF4F5F7));
    final fg = primary ? Colors.white : (isDark ? Colors.white : AppColors.textSecondary);
    return Expanded(
      child: ElevatedButton(
        style: ElevatedButton.styleFrom(
          backgroundColor: bg,
          foregroundColor: fg,
          padding: const EdgeInsets.symmetric(vertical: 16),
          shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
          elevation: 0,
        ),
        onPressed: onPressed,
        child: Text(label),
      ),
    );
  }
}

class SectionTitle extends StatelessWidget {
  final String title;
  final String? actionText;
  final VoidCallback? onAction;
  const SectionTitle({super.key, required this.title, this.actionText, this.onAction});
  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 8),
      child: Row(
        children: [
          Expanded(child: Text(title, style: Theme.of(context).textTheme.titleMedium?.copyWith(fontSize: 20, fontWeight: FontWeight.w700))),
          if (actionText != null)
            TextButton(onPressed: onAction, child: Text(actionText!, style: const TextStyle(color: AppColors.textSecondary))),
        ],
      ),
    );
  }
}

class RatingStars extends StatelessWidget {
  final double rating;
  const RatingStars({super.key, required this.rating});
  @override
  Widget build(BuildContext context) {
    final full = rating.floor();
    final half = (rating - full) >= 0.5;
    return Row(
      children: List.generate(5, (i) {
        final color = i < full || (half && i == full) ? AppColors.orange : AppColors.divider;
        return Icon(Icons.star, color: color, size: 16);
      }),
    );
  }
}

class QuantitySelector extends StatelessWidget {
  final int quantity;
  final VoidCallback onInc;
  final VoidCallback onDec;
  const QuantitySelector({super.key, required this.quantity, required this.onInc, required this.onDec});
  @override
  Widget build(BuildContext context) {
    return Row(
      children: [
        _circleIcon(context, Icons.remove, onDec),
        Padding(
          padding: const EdgeInsets.symmetric(horizontal: 12),
          child: Text('$quantity', style: const TextStyle(fontWeight: FontWeight.w600, fontSize: 16)),
        ),
        _circleIcon(context, Icons.add, onInc),
      ],
    );
  }

  Widget _circleIcon(BuildContext context, IconData icon, VoidCallback onTap) {
    final isDark = Theme.of(context).brightness == Brightness.dark;
    return InkWell(
      onTap: onTap,
      borderRadius: BorderRadius.circular(20),
      child: Container(
        decoration: BoxDecoration(
          border: Border.all(color: AppColors.divider),
          shape: BoxShape.circle,
        ),
        padding: const EdgeInsets.all(4),
        child: Icon(icon, size: 18),
      ),
    );
  }
}

class HeartIcon extends StatelessWidget {
  final bool filled;
  final VoidCallback? onTap;
  const HeartIcon({super.key, required this.filled, this.onTap});
  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: onTap,
      child: Icon(filled ? Icons.favorite : Icons.favorite_border, color: filled ? AppColors.red : AppColors.textSecondary),
    );
  }
}

class ChipTag extends StatelessWidget {
  final String label;
  final bool selected;
  final VoidCallback? onTap;
  const ChipTag({super.key, required this.label, this.selected = false, this.onTap});
  @override
  Widget build(BuildContext context) {
    final isDark = Theme.of(context).brightness == Brightness.dark;
    return GestureDetector(
      onTap: onTap,
      child: Container(
        padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 12),
        decoration: BoxDecoration(
          color: selected ? AppColors.purple : (isDark ? AppColors.cardDark : const Color(0xFFF4F5F7)),
          borderRadius: BorderRadius.circular(14),
        ),
        child: Text(label, style: TextStyle(color: selected ? Colors.white : (isDark ? Colors.white : AppColors.text), fontWeight: selected ? FontWeight.w600 : FontWeight.w400)),
      ),
    );
  }
}
