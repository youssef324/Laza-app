import 'package:flutter/material.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import '../theme.dart';
import '../ui/widgets.dart';
import '../services/firestore_service.dart';
import 'add_review_page.dart';

class ReviewsPage extends StatelessWidget {
  const ReviewsPage({super.key});

  @override
  Widget build(BuildContext context) {
    final fs = FirestoreService();

    return Scaffold(
      appBar: AppBar(
        leading: const CircularBackButton(),
        title: const Text('Reviews'),
      ),
      body: StreamBuilder<List<Map<String, dynamic>>>(
        stream: fs.getReviewsStream(),
        builder: (context, snapshot) {
          if (snapshot.connectionState == ConnectionState.waiting) {
            return const Center(child: CircularProgressIndicator());
          }

          final reviews = snapshot.data ?? [];

          return Column(
            children: [
              Padding(
                padding: const EdgeInsets.all(20),
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text('${reviews.length} Reviews',
                            style: const TextStyle(fontSize: 20, fontWeight: FontWeight.w700)),
                        const SizedBox(height: 4),
                        Row(
                          children: const [
                            Text('4.8', style: TextStyle(fontWeight: FontWeight.w600)),
                            SizedBox(width: 8),
                            RatingStars(rating: 4.8),
                          ],
                        ),
                      ],
                    ),
                    ElevatedButton.icon(
                      onPressed: () => Navigator.push(
                          context, MaterialPageRoute(builder: (_) => const AddReviewPage())),
                      icon: const Icon(Icons.edit_outlined, size: 18),
                      label: const Text('Add Review'),
                      style: ElevatedButton.styleFrom(
                        backgroundColor: AppColors.orange,
                        foregroundColor: Colors.white,
                        padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 12),
                        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
                        elevation: 0,
                      ),
                    ),
                  ],
                ),
              ),
              Expanded(
                child: reviews.isEmpty
                    ? const Center(child: Text('No reviews yet'))
                    : ListView.separated(
                        padding: const EdgeInsets.symmetric(horizontal: 20),
                        separatorBuilder: (_, __) => const SizedBox(height: 20),
                        itemCount: reviews.length,
                        itemBuilder: (_, i) {
                          final r = reviews[i];
                          final date = r['createdAt'] is Timestamp
                              ? (r['createdAt'] as Timestamp).toDate().toString().split(' ')[0]
                              : 'Just now';
                          final rating = (r['rating'] as num?)?.toDouble() ?? 0.0;

                          return Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              Row(children: [
                                const CircleAvatar(
                                    radius: 22,
                                    backgroundColor: AppColors.divider,
                                    child: Icon(Icons.person, color: AppColors.textSecondary)),
                                const SizedBox(width: 12),
                                Expanded(
                                    child: Text(r['name'] ?? 'User',
                                        style: const TextStyle(
                                            fontSize: 16, fontWeight: FontWeight.w600))),
                                Row(children: [
                                  Text('$rating',
                                      style: const TextStyle(fontWeight: FontWeight.w600)),
                                  const SizedBox(width: 4),
                                  const Text('rating',
                                      style: TextStyle(color: AppColors.textSecondary))
                                ]),
                              ]),
                              const SizedBox(height: 6),
                              Row(children: [
                                const Icon(Icons.schedule,
                                    size: 16, color: AppColors.textSecondary),
                                const SizedBox(width: 4),
                                Text(date, style: const TextStyle(color: AppColors.textSecondary))
                              ]),
                              const SizedBox(height: 12),
                              Text(r['comment'] ?? '',
                                  style:
                                      const TextStyle(color: AppColors.textSecondary, height: 1.5)),
                              const SizedBox(height: 8),
                              RatingStars(rating: rating),
                            ],
                          );
                        },
                      ),
              ),
            ],
          );
        },
      ),
    );
  }
}
