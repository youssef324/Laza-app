import 'package:flutter/material.dart';
import 'package:firebase_auth/firebase_auth.dart';
import '../theme.dart';
import '../ui/widgets.dart';
import '../services/auth_service.dart';
import 'home_catalog_page.dart';

class VerificationCodePage extends StatefulWidget {
  final String verificationId;
  const VerificationCodePage({super.key, required this.verificationId});

  @override
  State<VerificationCodePage> createState() => _VerificationCodePageState();
}

class _VerificationCodePageState extends State<VerificationCodePage> {
  final _controllers = List.generate(4, (_) => TextEditingController());
  final _auth = AuthService();
  bool loading = false;
  int seconds = 20;

  @override
  void initState() {
    super.initState();
    Future.doWhile(() async {
      await Future.delayed(const Duration(seconds: 1));
      if (!mounted) return false;
      setState(() => seconds = (seconds - 1).clamp(0, 999));
      return seconds > 0;
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(leading: _back(), title: const Text('Verification Code')),
      body: Padding(
        padding: const EdgeInsets.all(20),
        child: Column(
          children: [
            const Icon(Icons.lock_open, size: 100, color: AppColors.purple),
            const SizedBox(height: 20),
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceEvenly,
              children: _controllers.map((c) => _codeBox(c)).toList(),
            ),
            const Spacer(),
            Text(
              '00:${seconds.toString().padLeft(2, '0')} resend confirmation code.',
              style: const TextStyle(color: AppColors.textSecondary),
            ),
          ],
        ),
      ),
      bottomNavigationBar: PrimaryButton(
        label: loading ? 'Verifying...' : 'Confirm Code',
        onPressed: loading ? null : _verifyCode,
      ),
    );
  }

  void _verifyCode() async {
    String smsCode = _controllers.map((c) => c.text).join();
    if (smsCode.length < 4) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Please enter the 4-digit code')),
      );
      return;
    }

    setState(() => loading = true);
    try {
      await _auth.signInWithOTP(widget.verificationId, smsCode);
      if (!mounted) return;
      Navigator.pushAndRemoveUntil(
        context,
        MaterialPageRoute(builder: (_) => const HomeCatalogPage()),
        (route) => false,
      );
    } catch (e) {
      if (!mounted) return;
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text(e.toString())),
      );
    } finally {
      if (mounted) setState(() => loading = false);
    }
  }

  Widget _codeBox(TextEditingController c) {
    return SizedBox(
      width: 64,
      child: TextField(
        controller: c,
        textAlign: TextAlign.center,
        keyboardType: TextInputType.number,
        maxLength: 1,
        decoration: const InputDecoration(counterText: ""),
        onChanged: (v) {
          if (v.isNotEmpty) FocusScope.of(context).nextFocus();
        },
      ),
    );
  }

  Widget _back() => Container(
        margin: const EdgeInsets.only(left: 12),
        decoration: const BoxDecoration(
          color: Color(0xFFF4F5F7),
          shape: BoxShape.circle,
        ),
        child: const BackButton(),
      );
}
