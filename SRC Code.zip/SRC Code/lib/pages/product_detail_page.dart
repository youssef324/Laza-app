import 'package:flutter/material.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import '../models/product.dart';
import '../ui/widgets.dart';
import '../theme.dart';
import '../services/firestore_service.dart';
import 'cart_checkout_page.dart';
import 'reviews_page.dart';

class ProductDetailPage extends StatefulWidget {
  final Product product;
  const ProductDetailPage({super.key, required this.product});
  @override
  State<ProductDetailPage> createState() => _ProductDetailPageState();
}

class _ProductDetailPageState extends State<ProductDetailPage> {
  int sizeIndex = 2; // L
  bool readMore = false;
  final fs = FirestoreService();
  final List<String> sizes = ['S', 'M', 'L', 'XL', '2XL'];

  @override
  Widget build(BuildContext context) {
    final p = widget.product;
    final img = p.images.isNotEmpty ? p.images.first : null;
    final isDark = Theme.of(context).brightness == Brightness.dark;

    return Scaffold(
      extendBodyBehindAppBar: true,
      appBar: AppBar(
        backgroundColor: Colors.transparent,
        leading: const CircularBackButton(),
        actions: [
          CircularIconButton(
            onPressed: () => Navigator.push(
                context, MaterialPageRoute(builder: (_) => const CartCheckoutPage())),
            icon: const Icon(Icons.shopping_bag_outlined),
          )
        ],
      ),
      body: SingleChildScrollView(
        child: Column(
          children: [
            if (img != null)
              Image.network(
                img,
                height: 400,
                width: double.infinity,
                fit: BoxFit.cover,
              ),
            Container(
              padding: const EdgeInsets.all(20),
              decoration: BoxDecoration(
                color: isDark ? AppColors.bgDark : Colors.white,
                borderRadius: const BorderRadius.only(
                  topLeft: Radius.circular(24),
                  topRight: Radius.circular(24),
                ),
              ),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      Expanded(
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            const Text(
                              "Men's Printed Pullover Hoodie",
                              style: TextStyle(color: AppColors.textSecondary, fontSize: 13),
                            ),
                            const SizedBox(height: 4),
                            Text(
                              p.title,
                              style: const TextStyle(fontSize: 24, fontWeight: FontWeight.w700),
                            ),
                          ],
                        ),
                      ),
                      Column(
                        crossAxisAlignment: CrossAxisAlignment.end,
                        children: [
                          const Text(
                            'Price',
                            style: TextStyle(color: AppColors.textSecondary, fontSize: 13),
                          ),
                          const SizedBox(height: 4),
                          Text(
                            '\$${p.price.toStringAsFixed(0)}',
                            style: const TextStyle(fontSize: 24, fontWeight: FontWeight.w700),
                          ),
                        ],
                      ),
                    ],
                  ),
                  const SizedBox(height: 20),
                  SizedBox(
                    height: 80,
                    child: ListView.separated(
                      scrollDirection: Axis.horizontal,
                      itemCount: p.images.length,
                      separatorBuilder: (_, __) => const SizedBox(width: 12),
                      itemBuilder: (_, i) => ClipRRect(
                        borderRadius: BorderRadius.circular(14),
                        child: Image.network(p.images[i], width: 80, height: 80, fit: BoxFit.cover),
                      ),
                    ),
                  ),
                  const SizedBox(height: 24),
                  Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      const Text(
                        'Size',
                        style: TextStyle(fontSize: 18, fontWeight: FontWeight.w700),
                      ),
                      TextButton(
                        onPressed: () {},
                        child: const Text(
                          'Size Guide',
                          style: TextStyle(color: AppColors.textSecondary),
                        ),
                      ),
                    ],
                  ),
                  const SizedBox(height: 8),
                  Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: sizes.asMap().entries.map((e) {
                      final selected = sizeIndex == e.key;
                      return Expanded(
                        child: Padding(
                          padding: const EdgeInsets.symmetric(horizontal: 4),
                          child: ChipTag(
                            label: e.value,
                            selected: selected,
                            onTap: () => setState(() => sizeIndex = e.key),
                          ),
                        ),
                      );
                    }).toList(),
                  ),
                  const SizedBox(height: 24),
                  const Text(
                    'Description',
                    style: TextStyle(fontSize: 18, fontWeight: FontWeight.w700),
                  ),
                  const SizedBox(height: 12),
                  RichText(
                    text: TextSpan(
                      style: TextStyle(
                        color: isDark ? Colors.white70 : AppColors.textSecondary,
                        height: 1.5,
                        fontSize: 15,
                      ),
                      children: [
                        TextSpan(
                          text: readMore 
                            ? p.description 
                            : (p.description.length > 100 
                                ? p.description.substring(0, 100) 
                                : p.description),
                        ),
                        if (!readMore && p.description.length > 100)
                          WidgetSpan(
                            child: GestureDetector(
                              onTap: () => setState(() => readMore = true),
                              child: const Text(
                                ' Read More..',
                                style: TextStyle(fontWeight: FontWeight.w700, color: Colors.white),
                              ),
                            ),
                          ),
                      ],
                    ),
                  ),
                  const SizedBox(height: 24),
                  Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      const Text(
                        'Reviews',
                        style: TextStyle(fontSize: 18, fontWeight: FontWeight.w700),
                      ),
                      TextButton(
                        onPressed: () => Navigator.push(context, MaterialPageRoute(builder: (_) => const ReviewsPage())),
                        child: const Text(
                          'View All',
                          style: TextStyle(color: AppColors.textSecondary),
                        ),
                      ),
                    ],
                  ),
                  const SizedBox(height: 12),
                  StreamBuilder<List<Map<String, dynamic>>>(
                    stream: fs.getReviewsStream(),
                    builder: (context, snapshot) {
                      if (snapshot.connectionState == ConnectionState.waiting) {
                        return const Center(child: CircularProgressIndicator());
                      }
                      final reviews = snapshot.data ?? [];
                      if (reviews.isEmpty) {
                        return const Text('No reviews yet', style: TextStyle(color: AppColors.textSecondary));
                      }
                      
                      final latestReview = reviews.first;
                      final date = latestReview['createdAt'] is Timestamp
                          ? (latestReview['createdAt'] as Timestamp).toDate().toString().split(' ')[0]
                          : 'Just now';
                      final rating = (latestReview['rating'] as num?)?.toDouble() ?? 0.0;

                      return Row(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          const CircleAvatar(
                            radius: 24,
                            backgroundColor: AppColors.divider,
                            child: Icon(Icons.person, color: AppColors.textSecondary),
                          ),
                          const SizedBox(width: 12),
                          Expanded(
                            child: Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                Text(
                                  latestReview['name'] ?? 'User',
                                  style: const TextStyle(fontWeight: FontWeight.w600, fontSize: 16),
                                ),
                                const SizedBox(height: 4),
                                Row(
                                  children: [
                                    const Icon(Icons.access_time, size: 14, color: AppColors.textSecondary),
                                    const SizedBox(width: 4),
                                    Text(
                                      date,
                                      style: const TextStyle(color: AppColors.textSecondary, fontSize: 12),
                                    ),
                                  ],
                                ),
                                const SizedBox(height: 8),
                                Text(
                                  latestReview['comment'] ?? '',
                                  style: const TextStyle(color: AppColors.textSecondary, height: 1.4),
                                ),
                              ],
                            ),
                          ),
                          Column(
                            children: [
                              Text('$rating rating', style: const TextStyle(fontWeight: FontWeight.w600)),
                              const SizedBox(height: 4),
                              RatingStars(rating: rating),
                            ],
                          ),
                        ],
                      );
                    },
                  ),
                  const SizedBox(height: 24),
                  Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: const [
                          Text(
                            'Total Price',
                            style: TextStyle(fontSize: 16, fontWeight: FontWeight.w700),
                          ),
                          Text(
                            'with VAT,SD',
                            style: TextStyle(color: AppColors.textSecondary, fontSize: 12),
                          ),
                        ],
                      ),
                      Text(
                        '\$${p.price.toStringAsFixed(0)}',
                        style: const TextStyle(fontSize: 24, fontWeight: FontWeight.w700),
                      ),
                    ],
                  ),
                  const SizedBox(height: 20),
                ],
              ),
            ),
          ],
        ),
      ),
      bottomNavigationBar: PrimaryButton(
        label: 'Add to Cart',
        onPressed: () async {
          await fs.addToCart(p, size: sizes[sizeIndex]);
          if (!mounted) return;
          ScaffoldMessenger.of(context).showSnackBar(
            SnackBar(
              content: Text('${p.title} added to cart'),
              action: SnackBarAction(
                label: 'View Cart',
                onPressed: () => Navigator.push(
                    context, MaterialPageRoute(builder: (_) => const CartCheckoutPage())),
              ),
            ),
          );
        },
      ),
    );
  }
}
