import 'package:flutter/material.dart';
import '../theme.dart';
import '../ui/widgets.dart';
import '../services/auth_service.dart';
import 'home_catalog_page.dart';

class SignupPage extends StatefulWidget {
  const SignupPage({super.key});
  @override
  State<SignupPage> createState() => _SignupPageState();
}

class _SignupPageState extends State<SignupPage> {
  final _auth = AuthService();
  final _name = TextEditingController();
  final _email = TextEditingController();
  final _pwd = TextEditingController();
  bool remember = true;
  bool loading = false;

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(leading: _back(), title: const Text('Sign Up')),
      body: Padding(
        padding: const EdgeInsets.all(20),
        child: SingleChildScrollView(
          child: Column(
            children: [
              _field('Username', _name),
              const SizedBox(height: 8),
              _field('Email Address', _email),
              const SizedBox(height: 8),
              _field('Password', _pwd, obscure: true, suffix: const Text('Strong', style: TextStyle(color: AppColors.green))),
              const SizedBox(height: 16),
              Row(
                children: [
                  const Expanded(child: Text('Remember me')),
                  Switch(value: remember, onChanged: (v) => setState(() => remember = v), activeColor: AppColors.green),
                ],
              ),
            ],
          ),
        ),
      ),
      bottomNavigationBar: PrimaryButton(
        label: loading ? 'Please wait...' : 'Sign Up',
        onPressed: loading ? null : () async {
          if (_name.text.isEmpty || _email.text.isEmpty || _pwd.text.isEmpty) {
            ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Please fill all fields')));
            return;
          }
          setState(() => loading = true);
          try {
            await _auth.signup(
              name: _name.text.trim(),
              email: _email.text.trim(),
              password: _pwd.text.trim(),
            );
            if (!mounted) return;
            Navigator.pushAndRemoveUntil(context, MaterialPageRoute(builder: (_) => const HomeCatalogPage()), (_) => false);
          } catch (e) {
            if (!mounted) return;
            ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(e.toString())));
          } finally {
            if (mounted) setState(() => loading = false);
          }
        },
      ),
    );
  }

  Widget _field(String label, TextEditingController ctrl, {bool obscure = false, Widget? suffix, String? hint}) {
    return Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
      Text(label, style: const TextStyle(color: AppColors.textSecondary)),
      const SizedBox(height: 6),
      TextField(controller: ctrl, obscureText: obscure, decoration: InputDecoration(suffixIcon: suffix, hintText: hint)),
    ]);
  }

  Widget _back() => Container(margin: const EdgeInsets.only(left: 12), decoration: const BoxDecoration(color: Color(0xFFF4F5F7), shape: BoxShape.circle), child: const BackButton());
}
