import 'package:flutter/material.dart';
import 'package:firebase_auth/firebase_auth.dart';
import '../theme.dart';
import '../ui/widgets.dart';
import '../services/firestore_service.dart';

class AddReviewPage extends StatefulWidget {
  const AddReviewPage({super.key});
  @override
  State<AddReviewPage> createState() => _AddReviewPageState();
}

class _AddReviewPageState extends State<AddReviewPage> {
  final _name = TextEditingController();
  final _text = TextEditingController();
  final _fs = FirestoreService();
  double stars = 2.5;
  bool loading = false;

  @override
  void initState() {
    super.initState();
    // Pre-fill name if user is logged in
    final user = FirebaseAuth.instance.currentUser;
    if (user != null) {
      _name.text = user.displayName ?? '';
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        leading: const CircularBackButton(),
        title: const Text('Add Review'),
      ),
      body: Padding(
        padding: const EdgeInsets.all(20),
        child: Column(
          children: [
            _labeledField('Name', _name, hint: 'Type your name'),
            const SizedBox(height: 16),
            _labeledArea('How was your experience ?', _text, hint: 'Describe your experience?'),
            const SizedBox(height: 16),
            const Align(
                alignment: Alignment.centerLeft,
                child: Text('Star', style: TextStyle(fontWeight: FontWeight.w600))),
            Slider(
                min: 0.0,
                max: 5.0,
                divisions: 50,
                value: stars,
                onChanged: (v) => setState(() => stars = v),
                activeColor: AppColors.purple),
            const Spacer(),
          ],
        ),
      ),
      bottomNavigationBar: PrimaryButton(
        label: loading ? 'Submitting...' : 'Submit Review',
        onPressed: loading ? null : _submit,
      ),
    );
  }

  void _submit() async {
    if (_name.text.isEmpty || _text.text.isEmpty) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Please fill in all fields')),
      );
      return;
    }

    setState(() => loading = true);
    try {
      // For now, we save it as a general review. 
      // In a full app, you would pass a productId to this page.
      await _fs.addReview(
        name: _name.text.trim(),
        comment: _text.text.trim(),
        rating: stars,
      );

      if (!mounted) return;
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Review submitted successfully!')),
      );
      Navigator.pop(context);
    } catch (e) {
      if (!mounted) return;
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('Error: $e')),
      );
    } finally {
      if (mounted) setState(() => loading = false);
    }
  }

  Widget _labeledField(String label, TextEditingController c, {String? hint}) {
    return Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
      Text(label, style: const TextStyle(fontWeight: FontWeight.w600)),
      const SizedBox(height: 8),
      TextField(controller: c, decoration: InputDecoration(hintText: hint)),
    ]);
  }

  Widget _labeledArea(String label, TextEditingController c, {String? hint}) {
    return Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
      Text(label, style: const TextStyle(fontWeight: FontWeight.w600)),
      const SizedBox(height: 8),
      SizedBox(
          height: 160,
          child: TextField(
              controller: c,
              maxLines: null,
              expands: true,
              textAlignVertical: TextAlignVertical.top,
              decoration: InputDecoration(hintText: hint))),
    ]);
  }
}
