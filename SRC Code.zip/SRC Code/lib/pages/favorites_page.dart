import 'package:flutter/material.dart';
import '../theme.dart';
import '../ui/widgets.dart';
import '../services/firestore_service.dart';
import '../models/favorite_item.dart';
import 'cart_checkout_page.dart';
import 'home_catalog_page.dart';
import 'wallet_page.dart';

class FavoritesPage extends StatelessWidget {
  const FavoritesPage({super.key});

  @override
  Widget build(BuildContext context) {
    final fs = FirestoreService();
    final isDark = Theme.of(context).brightness == Brightness.dark;

    return Scaffold(
      appBar: AppBar(
        leading: const CircularBackButton(),
        title: const Text('Wishlist'),
        actions: [
          CircularIconButton(
            onPressed: () => Navigator.push(
                context, MaterialPageRoute(builder: (_) => const CartCheckoutPage())),
            icon: const Icon(Icons.shopping_bag_outlined),
          ),
        ],
      ),
      body: StreamBuilder<List<FavoriteItem>>(
        stream: fs.favoritesStream(),
        builder: (context, snap) {
          final items = snap.data ?? [];
          if (snap.connectionState == ConnectionState.waiting) {
            return const Center(child: CircularProgressIndicator());
          }

          return Column(
            children: [
              Padding(
                padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text('${items.length} Items',
                            style: const TextStyle(fontSize: 20, fontWeight: FontWeight.w700)),
                        const Text('in wishlist', style: TextStyle(color: AppColors.textSecondary)),
                      ],
                    ),
                    ElevatedButton.icon(
                      onPressed: () {},
                      icon: const Icon(Icons.edit_outlined, size: 18),
                      label: const Text('Edit', style: TextStyle(fontSize: 15, fontWeight: FontWeight.w500)),
                      style: ElevatedButton.styleFrom(
                        backgroundColor: isDark ? AppColors.cardDark : const Color(0xFFF4F5F7),
                        foregroundColor: isDark ? Colors.white : AppColors.text,
                        elevation: 0,
                        padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
                        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(10)),
                      ),
                    ),
                  ],
                ),
              ),
              Expanded(
                child: items.isEmpty
                    ? const Center(child: Text('No favorites yet'))
                    : Padding(
                        padding: const EdgeInsets.symmetric(horizontal: 16),
                        child: GridView.builder(
                          gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
                            crossAxisCount: 2,
                            mainAxisSpacing: 14,
                            crossAxisSpacing: 14,
                            childAspectRatio: 0.68,
                          ),
                          itemCount: items.length,
                          itemBuilder: (_, i) {
                            final item = items[i];
                            return Container(
                              decoration: BoxDecoration(
                                color: Theme.of(context).cardColor,
                                borderRadius: BorderRadius.circular(20),
                              ),
                              padding: const EdgeInsets.all(12),
                              child: Column(
                                crossAxisAlignment: CrossAxisAlignment.start,
                                children: [
                                  Expanded(
                                    child: Stack(
                                      children: [
                                        Positioned.fill(
                                          child: ClipRRect(
                                            borderRadius: BorderRadius.circular(15),
                                            child: Image.network(item.image, fit: BoxFit.cover),
                                          ),
                                        ),
                                        Positioned(
                                          top: 8,
                                          right: 8,
                                          child: HeartIcon(
                                            filled: true,
                                            onTap: () => fs.removeFavorite(item.productId),
                                          ),
                                        ),
                                      ],
                                    ),
                                  ),
                                  const SizedBox(height: 8),
                                  Text(item.title, maxLines: 2, overflow: TextOverflow.ellipsis),
                                  const SizedBox(height: 6),
                                  Text('\$${item.price.toStringAsFixed(0)}',
                                      style: const TextStyle(fontWeight: FontWeight.w700)),
                                ],
                              ),
                            );
                          },
                        ),
                      ),
              ),
            ],
          );
        },
      ),
      bottomNavigationBar: NavigationBar(
        selectedIndex: 1,
        onDestinationSelected: (i) {
          if (i == 0) {
            Navigator.pushAndRemoveUntil(
                context, MaterialPageRoute(builder: (_) => const HomeCatalogPage()), (_) => false);
          } else if (i == 2) {
            Navigator.push(context, MaterialPageRoute(builder: (_) => const CartCheckoutPage()));
          } else if (i == 3) {
            Navigator.push(context, MaterialPageRoute(builder: (_) => const WalletPage()));
          }
        },
        destinations: const [
          NavigationDestination(icon: Icon(Icons.home_outlined), label: 'Home'),
          NavigationDestination(icon: Icon(Icons.favorite), label: 'Wishlist'),
          NavigationDestination(icon: Icon(Icons.shopping_bag_outlined), label: 'Bag'),
          NavigationDestination(icon: Icon(Icons.account_balance_wallet_outlined), label: 'Wallet'),
        ],
      ),
    );
  }
}
