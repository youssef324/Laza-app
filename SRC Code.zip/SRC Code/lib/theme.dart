import 'package:flutter/material.dart';

class AppColors {
  static const purple = Color(0xFF8A66FF);
  static const purpleDark = Color(0xFF6F4FFF);
  static const purpleLight = Color(0xFFEDE8FF);
  static const bg = Color(0xFFF9F9FB);
  static const text = Color(0xFF1C1C1E);
  static const textSecondary = Color(0xFF8E8E93);
  static const green = Color(0xFF34C759);
  static const red = Color(0xFFFF3B30);
  static const orange = Color(0xFFFF9500);
  static const card = Colors.white;
  static const divider = Color(0xFFE5E5EA);

  // Dark Mode Colors
  static const bgDark = Color(0xFF1B262E);
  static const cardDark = Color(0xFF222E35);
  static const textDark = Colors.white;
  static const textSecondaryDark = Color(0xFF8E8E93);
}

ThemeData buildTheme({bool isDark = false}) {
  final base = isDark ? ThemeData.dark(useMaterial3: true) : ThemeData.light(useMaterial3: true);
  
  final colorScheme = ColorScheme.fromSeed(
    seedColor: AppColors.purple,
    brightness: isDark ? Brightness.dark : Brightness.light,
    background: isDark ? AppColors.bgDark : AppColors.bg,
  );

  return base.copyWith(
    colorScheme: colorScheme,
    scaffoldBackgroundColor: isDark ? AppColors.bgDark : AppColors.bg,
    appBarTheme: AppBarTheme(
      backgroundColor: isDark ? AppColors.bgDark : AppColors.bg,
      foregroundColor: isDark ? AppColors.textDark : AppColors.text,
      elevation: 0,
      centerTitle: true,
    ),
    inputDecorationTheme: InputDecorationTheme(
      filled: true,
      fillColor: isDark ? AppColors.cardDark : const Color(0xFFF4F5F7),
      border: OutlineInputBorder(
        borderRadius: BorderRadius.circular(14),
        borderSide: BorderSide.none,
      ),
      contentPadding: const EdgeInsets.symmetric(horizontal: 16, vertical: 14),
      hintStyle: TextStyle(color: isDark ? AppColors.textSecondaryDark : AppColors.textSecondary),
      labelStyle: TextStyle(color: isDark ? AppColors.textSecondaryDark : AppColors.textSecondary),
    ),
    dividerColor: AppColors.divider,
    cardColor: isDark ? AppColors.cardDark : AppColors.card,
    textTheme: base.textTheme.apply(
      bodyColor: isDark ? AppColors.textDark : AppColors.text,
      displayColor: isDark ? AppColors.textDark : AppColors.text,
    ),
  );
}
